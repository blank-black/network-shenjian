//test1.c
#include <stdio.h>
int fun1()
{
printf("1551265 ");
return 0; }
