//test3.c 
#include <stdio.h>
int fun1();
int fun2();
int main() {
    fun1();
    fun2();
    return 0;
}
