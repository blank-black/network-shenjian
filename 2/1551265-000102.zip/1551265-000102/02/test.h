//test.h
#include <stdio.h>
int fun1();
int fun2();
#define a 10
