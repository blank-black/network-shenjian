//test.cpp
#include <iostream>
using namespace std;
int main()
{
cout << "1551265+�Ų���";
return 0; 
}
