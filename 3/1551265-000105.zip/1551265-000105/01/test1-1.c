#include "stdio.h"
int main()
{
while(1)
{
printf("1551265\n");
sleep(5);
}
return 0;
}
