#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
int main()
{
while(1)
{
printf("�Ų���\n");
fflush(stdout);
sleep(5);
}
return 0;
}
